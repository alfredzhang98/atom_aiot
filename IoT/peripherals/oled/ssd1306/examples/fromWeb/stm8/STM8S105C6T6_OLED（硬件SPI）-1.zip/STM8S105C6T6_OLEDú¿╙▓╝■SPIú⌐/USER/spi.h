#ifndef __SPI__H
#define __SPI__H


/*inclides-------------------------------------------------*/
#include "STM8S105C6.h"

#define	OLED_DC_Clr()			(PE_ODR &= 0x7f)
#define	OLED_DC_Set()			(PE_ODR |= 0x80)
#define	OLED_CS_Clr()			(PE_ODR &= 0xdf)
#define	OLED_CS_Set()			(PE_ODR |= 0x20)
#define	OLED_RES_Clr()			(PE_ODR &= 0xaf)
#define	OLED_RES_Set()			(PE_ODR |= 0x40)


/*declaration----------------------------------------------*/
void SPI_Init(void);	//声明SPI初始化函数
void SPI_Write_Byte(unsigned char data);	//声明SPI写数据函数



#endif