#include "stm32f10x.h"
#include "oled.h"

int main(void)
{
	OLED_Init();  //OLED��ʼ��
	OLED_Clear();
	
	OLED_ShowString(30,2,"OLED TEST");// OLED TEST
	OLED_ShowCHinese(16,0,0);// ��
	OLED_ShowCHinese(32,0,1);// ��
	OLED_ShowCHinese(48,0,2);// ��
	OLED_ShowCHinese(64,0,3);// ��
	OLED_ShowCHinese(80,0,4);// ��
	OLED_ShowCHinese(96,0,5);// ��
	
	while(1)
	{
		
	}
}
